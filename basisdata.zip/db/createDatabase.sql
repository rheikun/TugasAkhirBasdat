CREATE DATABASE car_rental;
