<?php
    $koneksi = mysqli_connect('localhost', 'root', '', 'car_rental') 
    or die ('koneksi gagal');
?>